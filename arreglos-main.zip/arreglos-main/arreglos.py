#Hola soy un comentario 

nombre = "Carlos"
edad = 30
estatura = 1.7
esDocente = True

frutas = ["Manzana" , "Pera" , "Frutilla" ]
print(frutas[2])

estudiantesNombres = [ "Maxi" , "Richard", "Benja", "Diego" ]
estudiantesCurso = [ "Primero A" , "Cuarto C", "Tercero c", "Tercero c" ]
estudiantesEdad = [ 20 , 19 ]
print(estudiantesNombres[0], estudiantesCurso[0], estudiantesEdad[0])


#Entonces, como se hace???
estudiantes = [ 
    { 'nombre' : "Maxi" , 'edad' : 20 , 'curso' : "2A" },
    { 'nombre' : "Richard", 'edad': 19, 'curso' : "1B" }
]
print(estudiantes)
print('######')
print( estudiantes[0]['curso'] )

#ola profe soy amador 😎 :v
